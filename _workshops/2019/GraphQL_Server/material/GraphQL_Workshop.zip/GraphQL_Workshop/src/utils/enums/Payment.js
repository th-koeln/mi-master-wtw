module.exports = Object.freeze({
    CREDITCARD: 'creditcard',
    BANKTRANSFER: 'banktransfer',
    CASH: 'cash',
    PAYPAL: 'paypal'
})