module.exports = Object.freeze({
    MAIL: 'mail',
    PICKUP: 'pickup'
})