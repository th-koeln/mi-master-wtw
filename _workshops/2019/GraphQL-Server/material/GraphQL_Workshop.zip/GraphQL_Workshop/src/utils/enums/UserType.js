module.exports = Object.freeze({
    CONSUMER: 'consumer',
    PRODUCER: 'producer'
})