var http = require("http");

http.createServer(function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/plain'});

   var MongoClient = require('mongodb').MongoClient;

    // Connect to the db
    MongoClient.connect("mongodb://mongo:27017/docker", function (err, db) {
    
        if(err) {
            response.end('Fehler! \n');
        } else {
            response.end('Verbunden! \n');
        }                    
    });
}).listen(8081);
