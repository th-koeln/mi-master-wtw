const apiKey = '0025c42c107740809ca3fde40924ea77';
const main = document.querySelector('div#main-wrapper');
const sourceSelector = document.querySelector('#source-selector');
const defaultSource = 't3n';

window.addEventListener('load', async e => {
  showNews();
  await updateSources();
  sourceSelector.value = defaultSource;

  sourceSelector.addEventListener('change', e => {
    showNews(e.target.value);
  });


  /*
   ---- aufgabe 1: serivce worker registration ----
  */
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('../../sw.js')
      .then(function(registration) {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      }, function(err) {
        console.log('ServiceWorker registration failed: ', err);
      });
  }
  /*
   ---- serivce worker registration ----
  */


})

async function showNews(source = defaultSource){
  const res = await fetch(`https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${apiKey}`);
  const json = await res.json();

  main.innerHTML = json.articles.map(createArticle).join('\n');
}

async function updateSources(){
  const res = await fetch('https://newsapi.org/v1/sources');
  const json = await res.json();

  sourceSelector.innerHTML = json.sources
    .map(src => `<option value="${src.id}">${src.name}</option>`)
    .join('\n');
}

function createArticle(article) {
    return`
    <figure class="news-card">
      <img src="${article.urlToImage}" alt="pwa pic"/>
      <figcaption>
        <h3>${article.title}</h3>
        <p>${article.description}</p>
        <button>Read More</button>
      </figcaption><a href="${article.url} aria-label="test"></a>
    </figure>
    `;
}
