
var dynamicCache = 'dynamic-cache';

/*
 ---- aufgabe2: install service worker with static resources ----
*/
var staticCache = 'static-cache';
const staticFiles = [
  '/',
  '/index.html',
  '/assets/info/info.html',
  '/assets/css/styles.css',
  '/assets/css/fonts.css',
  '/assets/js/app.js',
  '/assets/js/navigation.js',
  '/assets/js/scrollup.js',
  '/assets/images/signs-icon/down-arrow.svg',
  '/assets/images/signs-icon/menu-icon.svg',
  '/assets/images/signs-icon/up-arrow.svg',
  '/assets/images/fails-img/pwanews-fails.png',
  '/assets/fonts/Open_Sans_Condensed/OpenSansCondensed-Light.ttf',
  '/assets/fonts/Thasadith/Thasadith-Regular.ttf',
  '/fallback.json'
];

self.addEventListener('install', function(event){
  console.log('[Service Worker] Installing Service Worker...', event);
  event.waitUntil(
    caches.open(staticCache)
      .then(function(cache){
        console.log('Opened Cache');
        return cache.addAll(staticFiles);
      })
  );
});
/*
 ---- install service worker with static resources ----
*/


/*
 ---- aufgabe 3: fetch static resources ----
*/
// self.addEventListener('fetch', function(event){
//   event.respondWith(
//     caches.match(event.request)
//   );
// });
/*
 ---- fetch static resources ----
*/


/*
 ---- aufgabe 4: Generic Fallback-Strategy ----
*/
self.addEventListener('fetch', function(event){
  event.respondWith(
    // try the cache
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }else {
          // fall back to network
          return fetch(event.request)
          .then(function (res) {
            return caches.open(dynamicCache)
              .then(function (cache) {
                cache.put(event.request, res.clone());
                return res;
              })
            })
            // if both faile, show generic fallback
            .catch(function (error) {
              return caches.match('./fallback.json');
            });
          }
        })
    );
})
/*
 ---- Generic Fallback-Strategy ----
*/
