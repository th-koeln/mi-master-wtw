var navigationClickOpen = document.getElementById('nav-icon');
var navigationClickClose = document.querySelector('.closeBtn');
var overlay = document.querySelector('.overlay');

function openNav() {
  overlay.style.height = "100%";
}

function closeNav() {
  overlay.style.height = "0%";
}

navigationClickOpen.addEventListener('click', openNav);
navigationClickClose.addEventListener('click', closeNav);
