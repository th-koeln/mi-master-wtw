
/*
 ---- aufgabe 2: install service worker with static resources ----
*/

/*
 ---- install service worker with static resources ----
*/



/*
 ---- aufgabe 3: fetch static resources ----
*/

/*
 ---- fetch static resources ----
*/



/*
 ---- aufgabe4: Generic Fallback-Strategy ----
*/

/*
 ---- Generic Fallback-Strategy ----
*/
