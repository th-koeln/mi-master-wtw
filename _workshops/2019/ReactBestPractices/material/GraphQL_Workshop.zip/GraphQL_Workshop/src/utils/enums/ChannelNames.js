module.exports = Object.freeze({
    REVIEW_ADDED_CHANNEL: 'reviewAdded',
    ORDER_ADDED_CHANNEL: 'orderAdded'
})