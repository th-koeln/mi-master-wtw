module.exports = Object.freeze({
    QUANTITY: 'quantity',
    LITER: 'liter',
    KILOGRAM: 'kilogram'
})