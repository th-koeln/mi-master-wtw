module.exports = {
  app: {
    root: 'http://localhost',
    port: 3000,
    playground: '/',
    voyager: '/voyager',
    endpoint: '/graphql',
  }
}
